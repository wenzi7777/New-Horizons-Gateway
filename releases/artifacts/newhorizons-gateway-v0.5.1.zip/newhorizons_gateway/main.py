from __future__ import annotations

import argparse
import json
import os
import signal
import threading
import time
from typing import Any

from .arduino_protocol import is_arduino_heartbeat_packet, is_arduino_stream_packet
from .config_store import GatewayConfigStore
from .console_runtime import write_console_status
from .boot_state import GatewayHealthStore
from .discovery import DiscoveryResponder
from .local_device import LocalUDPIngestServer, packet_device_uid as stream_packet_device_uid
from .result_chunks import RESULT_CHUNK_TYPE, ResultChunkReassembler
from .state import GatewayState
from .udp_control import UDPCommandDispatcher, normalize_device_uid
from .update_manager import GatewayUpdateManager
from .upstream_wss import UpstreamWSSClient
from .web import GatewayWebServer


def _install_signal_handlers(stop_handler: Any) -> None:
    if threading.current_thread() is not threading.main_thread():
        return
    signal.signal(signal.SIGINT, stop_handler)
    signal.signal(signal.SIGTERM, stop_handler)


def run(config_path: str | None = None, stop_event: threading.Event | None = None) -> None:
    config_store = GatewayConfigStore(config_path)
    config = config_store.snapshot()
    health_store = GatewayHealthStore(
        os.getenv("NEWHORIZONS_GATEWAY_HEALTH_PATH") or str(config_store.path.parent / "health.json"),
    )
    slot_name = str(os.getenv("NEWHORIZONS_GATEWAY_SLOT_NAME") or "")
    expected_version = str(os.getenv("NEWHORIZONS_GATEWAY_EXPECTED_VERSION") or __version__)
    state = GatewayState(control_stale_sec=float(config.get("control_stale_sec", 16.0)))
    arduino_hosts: dict[str, str] = {}
    result_chunks = ResultChunkReassembler()
    running = True

    def stop(_signum: int, _frame: object) -> None:
        nonlocal running
        running = False

    def command_expired(payload: dict[str, Any]) -> bool:
        try:
            expires_at_ms = int(payload.get("expires_at_ms") or 0)
        except Exception:
            expires_at_ms = 0
        return bool(expires_at_ms and int(time.time() * 1000) > expires_at_ms)


    _install_signal_handlers(stop)

    health_store.write({
        "slot": slot_name,
        "version": expected_version,
        "ready": False,
        "phase": "starting",
        "web_port": int(config.get("listen_web_port", 5052)),
    })

    def on_command(device_uid: str, payload: dict[str, Any]) -> None:
        normalized_uid = normalize_device_uid(device_uid)
        if command_expired(payload):
            upstream.send_device_message(
                "result",
                {
                    "device_uid": device_uid,
                    "request_id": payload.get("request_id", ""),
                    "command": payload.get("command", ""),
                    "status": "error",
                    "message": "command_expired",
                },
            )
            return
        if udp_commands.send_command(normalized_uid, payload):
            return
        upstream.send_device_message(
            "result",
            {
                "device_uid": normalized_uid,
                "request_id": payload.get("request_id", ""),
                "command": payload.get("command", ""),
                "status": "error",
                "message": "device_not_connected_to_gateway",
            },
        )

    def on_udp_delivery_timeout(device_uid: str, payload: dict[str, Any]) -> None:
        if str(payload.get("command") or "") == "findme_switch_gateway":
            claim_id = str(payload.get("claim_id") or "")
            if claim_id:
                state.fail_claim_delivery(
                    claim_id,
                    "switch_command_delivery_timeout",
                )
        upstream.send_device_message(
            "result",
            {
                "device_uid": device_uid,
                "request_id": payload.get("request_id", ""),
                "command": payload.get("command", ""),
                "status": "error",
                "message": "command_delivery_timeout",
            },
        )

    def on_upstream_message(message: dict[str, Any]) -> None:
        if message.get("type") == "gateway_hello_ack":
            update_manager.set_server_latest_version(str(message.get("latest_gateway_version") or ""))
        if message.get("type") == "gateway_claim_update":
            claim_id = str(message.get("claim_id") or "")
            if claim_id:
                state.update_claim(
                    claim_id,
                    state=str(message.get("state") or "updated"),
                    last_error=str(message.get("error") or message.get("message") or ""),
                )

    def send_udp_datagram(payload: bytes, addr: tuple[str, int]) -> None:
        udp_server.send_datagram(payload, addr)

    upstream = UpstreamWSSClient(
        server_url=str(config["server_url"]),
        gateway_id=str(config["gateway_id"]),
        auth_token=str(config.get("auth_token") or ""),
        on_command=on_command,
        on_message=on_upstream_message,
    )
    udp_commands = UDPCommandDispatcher(send_udp_datagram, on_delivery_timeout=on_udp_delivery_timeout)

    def handle_udp_control(payload: bytes, addr: tuple[str, int]) -> None:
        try:
            frame = json.loads(payload.decode("utf-8"))
        except Exception:
            return
        if not isinstance(frame, dict):
            return
        if str(frame.get("type") or "") == RESULT_CHUNK_TYPE:
            # Oversized results are split into UDP chunks; reassemble before
            # processing. Returns None until every chunk for the request arrives.
            frame = result_chunks.add(frame)
            if frame is None:
                return
        frame_payload = frame.get("payload") if isinstance(frame.get("payload"), dict) else {}
        device_uid = normalize_device_uid(frame.get("device_uid")) or normalize_device_uid(frame_payload.get("device_uid")) or normalize_device_uid(frame_payload.get("device_id"))
        if not device_uid or config_store.is_denied(device_uid):
            return
        udp_commands.set_session(device_uid, addr)
        message_type = str(frame.get("type") or "")
        data = dict(frame_payload)
        data.setdefault("device_uid", device_uid)
        data.setdefault("request_id", frame.get("request_id", ""))
        data.setdefault("received_at_ms", int(time.time() * 1000))
        if message_type == "ack":
            udp_commands.handle_ack(device_uid, frame)
            return
        if message_type in ("hello", "status", "update_progress", "result"):
            if message_type == "result":
                if "cmd" in data and "command" not in data:
                    data["command"] = data["cmd"]
                if "ok" in data and "status" not in data:
                    data["status"] = "ok" if data.get("ok") else "error"
                data.setdefault("transport_path", "arduino_udp")
                udp_commands.handle_result(device_uid, data)
            state.record_control(device_uid, message_type, data, addr, connected=True)
            upstream.send_device_message(message_type, data)

    def on_udp_packet(payload: bytes, addr: tuple[str, int]) -> None:
        if payload.lstrip().startswith(b"{"):
            handle_udp_control(payload, addr)
            return
        is_arduino = is_arduino_stream_packet(payload)
        is_heartbeat = is_arduino_heartbeat_packet(payload)
        device_uid = stream_packet_device_uid(payload)
        denied = bool(device_uid and config_store.is_denied(device_uid))
        same_arduino_peer = bool(arduino_hosts.get(device_uid or "") == addr[0])
        if is_heartbeat and device_uid and not denied:
            arduino_hosts[device_uid] = addr[0]
            udp_commands.set_session(device_uid, addr)
            state.record_heartbeat(
                device_uid,
                {
                    "device_uid": device_uid,
                    "device_name": "New Horizons OS-{}".format(device_uid),
                    "protocol": "NHO/Arduino/1",
                    "transport_path": "arduino_heartbeat",
                },
                addr,
            )
        elif is_arduino and device_uid and not denied and (state.findme_allows_stream(device_uid, addr) or same_arduino_peer):
            arduino_hosts[device_uid] = addr[0]
            udp_commands.set_session(device_uid, addr)
            state.record_control(
                device_uid,
                "status",
                {
                    "device_uid": device_uid,
                    "device_name": "New Horizons OS-{}".format(device_uid),
                    "protocol": "NHO/Arduino/1",
                    "transport_path": "arduino_udp",
                },
                addr,
                connected=True,
            )
        serving = bool(device_uid and (is_arduino or state.is_serving(device_uid)))
        forwarded = bool(device_uid and not denied and serving and not is_heartbeat)
        if device_uid and not is_heartbeat:
            state.record_udp_packet(device_uid, len(payload), forwarded)
        if forwarded:
            upstream.send_packet(payload)

    udp_server = LocalUDPIngestServer(str(config["listen_udp_host"]), int(config["listen_udp_port"]), on_udp_packet)
    discovery = DiscoveryResponder(
        str(config["listen_discovery_host"]),
        int(config["listen_discovery_port"]),
        gateway_id=str(config["gateway_id"]),
        udp_port=lambda: int(udp_server.bound_port),
        priority=int(config["discovery_priority"]),
        gateway_name=str(config["gateway_name"]),
        upstream_status=lambda: "online" if upstream.is_connected() else "offline",
        is_denied=config_store.is_denied,
        active_claim=state.active_claim_for,
        on_request=state.record_findme_request,
    ) if config.get("discovery_enabled") else None

    runtime_started = False

    def publish_console_status(current_config: dict[str, Any]) -> None:
        upstream_state = upstream.status()
        update_state = update_manager.state()
        write_console_status(
            None,
            {
                "enabled": bool(current_config.get("enabled")),
                "gateway_id": str(current_config.get("gateway_id") or ""),
                "gateway_name": str(current_config.get("gateway_name") or "New Horizons Gateway"),
                "server_url": str(current_config.get("server_url") or ""),
                "target_mode": str(current_config.get("target_mode") or ""),
                "web_ui_url": "http://127.0.0.1:{}".format(int(current_config.get("listen_web_port", 5052))),
                "listen_udp_port": int(udp_server.bound_port),
                "listen_discovery_port": int(discovery.bound_port) if discovery is not None else int(current_config.get("listen_discovery_port", 22346)),
                "upstream_connected": bool(upstream_state.get("connected")),
                "required_update": bool(update_state.get("required_update")),
                "latest_gateway_version": str(update_state.get("latest_gateway_version") or ""),
                "current_version": str(update_state.get("current_version") or ""),
            },
        )

    def apply_runtime_config(current_config: dict[str, Any]) -> None:
        nonlocal runtime_started
        upstream.gateway_id = str(current_config.get("gateway_id") or "")
        upstream.update_server(str(current_config["server_url"]), str(current_config.get("auth_token") or ""))
        if discovery is not None:
            discovery.gateway_id = str(current_config.get("gateway_id") or "")
            discovery.gateway_name = str(current_config.get("gateway_name") or "New Horizons Gateway")
            discovery.priority = int(current_config.get("discovery_priority", 100))
        should_run = bool(current_config.get("enabled"))
        if should_run and not runtime_started:
            upstream.start()
            udp_server.start()
            if discovery is not None:
                discovery.start()
            runtime_started = True
        elif not should_run and runtime_started:
            if discovery is not None:
                discovery.stop()
            udp_server.stop()
            upstream.stop()
            runtime_started = False
        publish_console_status(current_config)

    update_manager = GatewayUpdateManager()
    if stop_event is not None:
        update_manager.set_restart_callback(stop_event.set)
    web_server = GatewayWebServer(
        str(config["listen_web_host"]),
        int(config["listen_web_port"]),
        config_store,
        state,
        upstream,
        udp_commands,
        discovery=discovery,
        on_config_saved=apply_runtime_config,
        update_manager=update_manager,
    )

    web_server.start()
    apply_runtime_config(config)
    health_store.write({
        "slot": slot_name,
        "version": expected_version,
        "ready": True,
        "phase": "running",
        "web_port": int(config.get("listen_web_port", 5052)),
    })
    print(
        "New Horizons Gateway web=http://127.0.0.1:{} enabled={} udp={}:{} findme={}:{} upstream={}".format(
            config["listen_web_port"],
            bool(config.get("enabled")),
            config["listen_udp_host"],
            config["listen_udp_port"],
            config["listen_discovery_host"],
            config["listen_discovery_port"],
            config["server_url"],
        )
    )
    last_gateway_status = 0.0
    try:
        while running:
            if stop_event is not None and stop_event.is_set():
                running = False
                continue
            time.sleep(0.5)
            now = time.time()
            if now - last_gateway_status >= 5.0:
                last_gateway_status = now
                current_config = config_store.snapshot()
                upstream.send_gateway_status({
                    "gateway_name": current_config.get("gateway_name", "New Horizons Gateway"),
                    "gateway_id": current_config.get("gateway_id", ""),
                    "enabled": bool(current_config.get("enabled")),
                    "version": update_manager.state().get("current_version", ""),
                    "target_mode": current_config.get("target_mode", ""),
                    "server_url": current_config.get("server_url", ""),
                    "listen_udp_port": int(udp_server.bound_port),
                    "listen_discovery_port": int(discovery.bound_port) if discovery is not None else int(current_config.get("listen_discovery_port", 22346)),
                    "upstream": upstream.status(),
                    "udp_control": udp_commands.snapshot(),
                    "state": state.snapshot(current_config.get("denied_devices", [])),
                })
                publish_console_status(current_config)
            udp_commands.service()
            result_chunks.purge()
    finally:
        health_store.write({
            "slot": slot_name,
            "version": expected_version,
            "ready": False,
            "phase": "stopped",
            "web_port": int(config.get("listen_web_port", 5052)),
        })
        if discovery is not None:
            discovery.stop()
        web_server.stop()
        udp_server.stop()
        upstream.stop()


def main() -> None:
    parser = argparse.ArgumentParser(description="New Horizons local UDP/JSON to WSS gateway")
    parser.add_argument("--config", help="Path to host gateway config", default=None)
    args = parser.parse_args()
    run(config_path=args.config)


if __name__ == "__main__":
    main()
