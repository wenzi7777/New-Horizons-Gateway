from __future__ import annotations

import json
import secrets
import threading
import urllib.error
import urllib.request
from typing import Any, Callable
from urllib.parse import urlparse

from flask import Flask, jsonify, request
from werkzeug.serving import make_server

from . import __version__
from .config_store import GatewayConfigStore, LOCAL_URL, PRODUCTION_URL, validate_gateway_id
from .state import GatewayState
from .update_manager import GatewayUpdateManager


ConfigCallback = Callable[[dict[str, Any]], None]

_DEVICE_CONTROL_PORT = 13250


PAGE = """<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>New Horizons Gateway</title>
  <style>
    :root { color-scheme:light; --bg:#f7f7f3; --panel:#fffffb; --ink:#151816; --muted:#697068; --line:#d9ddd4; --green:#3f7b61; --danger:#b6554c; --warn:#b5842a; --blue:#3f648f; }
    * { box-sizing:border-box; }
    body { margin:0; font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; background:var(--bg); color:var(--ink); }

    /* ── Topbar ── */
    .topbar { position:sticky; top:0; z-index:20; background:var(--panel); border-bottom:1px solid var(--line); padding:0 22px; display:flex; align-items:center; gap:14px; height:52px; }
    .topbar-brand { font-size:16px; font-weight:700; flex:1; letter-spacing:-.01em; }
    .topbar-gw { font-family:ui-monospace,monospace; font-size:12px; color:var(--muted); }

    /* ── Layout ── */
    main { max-width:1120px; margin:0 auto; padding:24px 20px 52px; }
    h2 { margin:0 0 14px; font-size:17px; }
    .grid { display:grid; grid-template-columns:repeat(12,1fr); gap:14px; }
    .panel { background:var(--panel); border:1px solid var(--line); border-radius:8px; padding:18px; box-shadow:0 1px 2px rgba(0,0,0,.03); }
    .span-4 { grid-column:span 4; } .span-6 { grid-column:span 6; } .span-8 { grid-column:span 8; } .span-12 { grid-column:span 12; }

    /* ── Stat cards ── */
    .stat { color:var(--muted); display:block; font-size:12px; text-transform:uppercase; letter-spacing:.05em; margin-bottom:6px; }
    strong { font-size:18px; }

    /* ── Badges ── */
    .badge { display:inline-flex; align-items:center; gap:5px; min-height:28px; padding:3px 10px; border:1px solid var(--line); border-radius:999px; font-size:13px; color:var(--muted); background:#f1f2ee; }
    .badge::before { content:''; width:6px; height:6px; border-radius:50%; background:currentColor; opacity:.65; flex-shrink:0; }
    .badge.ok { border-color:#aac9ba; color:var(--green); background:#f4fbf7; }
    .badge.err { border-color:#d9aaa4; color:var(--danger); background:#fff7f5; }
    .badge.warn { border-color:#e0c58b; color:var(--warn); background:#fffaf0; }

    /* ── Status pills (device table) ── */
    .pill { display:inline-block; padding:2px 8px; border-radius:4px; font-size:12px; font-weight:600; }
    .pill-serving { background:#ebf7f2; color:var(--green); }
    .pill-nearby  { background:#eef2fa; color:var(--blue); }
    .pill-denied  { background:#fdf2f1; color:var(--danger); }
    .pill-pending { background:#fef8ee; color:var(--warn); }

    /* ── Forms ── */
    label { color:var(--muted); font-size:13px; }
    input, select { width:100%; min-height:40px; padding:8px 10px; border:1px solid var(--line); border-radius:7px; background:#fff; color:var(--ink); font:inherit; }
    input:focus, select:focus { outline:2px solid var(--blue); outline-offset:1px; }

    /* ── Buttons ── */
    button { min-height:40px; padding:8px 16px; border:1px solid var(--line); border-radius:7px; background:#fff; color:var(--ink); font:inherit; cursor:pointer; }
    button:hover:not(:disabled) { background:var(--bg); }
    button.primary { background:var(--green); color:#fff; border-color:var(--green); }
    button.primary:hover:not(:disabled) { background:#336553; }
    button.secondary { color:var(--blue); border-color:#b8c7d9; background:#f7faff; }
    button.danger { color:var(--danger); border-color:#d9aaa4; }
    button.danger:hover:not(:disabled) { background:#fff7f5; }
    button.sm { min-height:34px; padding:5px 12px; font-size:13px; }
    button:disabled { opacity:.5; cursor:not-allowed; }

    /* ── Field + Toolbar ── */
    .field { display:grid; gap:5px; }
    .field.narrow { flex:0 0 160px; min-width:140px; }
    .toolbar { display:flex; gap:10px; flex-wrap:wrap; align-items:end; }
    .toolbar .field { flex:1; min-width:160px; }
    .button-row { display:flex; gap:8px; flex-wrap:wrap; }
    .header-row, .section-head { display:flex; justify-content:space-between; gap:16px; align-items:flex-start; }
    .stack { display:grid; gap:14px; }

    /* ── Toggle switch ── */
    .sw-row { display:flex; gap:10px; align-items:center; min-height:40px; }
    .sw { position:relative; display:inline-block; width:46px; height:26px; flex-shrink:0; }
    .sw input { opacity:0; width:0; height:0; }
    .sw-track { position:absolute; inset:0; background:var(--line); border-radius:26px; cursor:pointer; transition:.15s; }
    .sw-track::after { content:''; position:absolute; width:20px; height:20px; left:3px; top:3px; background:#fff; border-radius:50%; transition:.15s; }
    .sw input:checked + .sw-track { background:var(--green); }
    .sw input:checked + .sw-track::after { transform:translateX(20px); }

    /* ── Wizard ── */
    .wizard-wrap { max-width:500px; margin:40px auto 0; }
    .wiz-steps { display:flex; gap:6px; margin-bottom:28px; }
    .wiz-pip { height:4px; flex:1; border-radius:2px; background:var(--line); }
    .wiz-pip.active { background:var(--green); }
    .wiz-pip.done { background:#aac9ba; }
    .wiz-step { display:none; }
    .wiz-step.active { display:block; }
    .wiz-title { font-size:22px; font-weight:700; margin:0 0 6px; }
    .wiz-sub { color:var(--muted); margin:0 0 22px; font-size:15px; }
    .wiz-actions { display:flex; justify-content:flex-end; gap:10px; margin-top:20px; }
    .wiz-confirm-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:16px; }
    .wiz-card { border:1px solid var(--line); border-radius:6px; padding:12px; background:#fcfcf8; }

    /* ── Summary grid ── */
    .summary-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:10px; }
    .summary-card { border:1px solid var(--line); border-radius:7px; padding:12px; background:#fcfcf8; }
    .summary-card strong { font-size:15px; }

    /* ── Update center ── */
    .update-center { background:linear-gradient(180deg,#fffdf6 0%,#fff 100%); border-color:#e5d8b4; }
    .update-center.ok { background:linear-gradient(180deg,#f3fbf4 0%,#fbfffb 100%); border-color:#b8d7bf; box-shadow:0 1px 2px rgba(63,123,97,.08); }
    .update-grid { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:10px; margin:16px 0; }
    .update-card { border:1px solid #eadfbe; border-radius:10px; padding:14px; background:rgba(255,252,243,.95); }
    .update-center.ok .update-card,
    .update-center.ok .summary-card { border-color:#c5dec9; background:rgba(247,255,248,.96); }
    .update-card strong { font-size:16px; }
    .update-notes { min-height:140px; margin:0; padding:14px; border:1px solid #eadfbe; border-radius:10px; background:#fffdfa; white-space:pre-wrap; word-break:break-word; font:13px/1.55 ui-monospace,monospace; color:#333; }
    .update-banner { margin:12px 0 0; padding:10px 12px; border-radius:8px; background:#fff6da; border:1px solid #e7cf84; color:#755712; }
    .update-banner.ok { background:#edf8f0; border-color:#bed8c4; color:#2f694f; }
    .update-banner.error { background:#fff2ef; border-color:#e0b0ab; color:#9a3f37; }
    .progress-stack { display:grid; gap:10px; margin-top:16px; }
    .progress-head { display:flex; justify-content:space-between; gap:10px; align-items:center; margin-bottom:6px; font-size:13px; color:var(--muted); }
    .progress-track { width:100%; height:10px; border-radius:999px; background:#ebede6; overflow:hidden; border:1px solid #d8ddd0; }
    .progress-fill { height:100%; width:0%; background:linear-gradient(90deg,#80b48d 0%,#3f7b61 100%); transition:width .2s ease; }
    .progress-track.warn .progress-fill { background:linear-gradient(90deg,#f0c66a 0%,#c89227 100%); }

    /* ── Force update overlay ── */
    .overlay { position:fixed; inset:0; z-index:40; display:flex; align-items:center; justify-content:center; padding:20px; background:rgba(14,20,16,.72); backdrop-filter:blur(6px); }
    .overlay[hidden] { display:none; }
    .overlay-card { width:min(820px,100%); max-height:calc(100vh - 40px); overflow:auto; padding:24px; border-radius:18px; border:1px solid rgba(255,255,255,.18); background:linear-gradient(180deg,#fffdf7 0%,#fff 100%); box-shadow:0 28px 80px rgba(0,0,0,.28); }
    .overlay-kicker { display:inline-flex; align-items:center; gap:8px; margin-bottom:10px; padding:6px 12px; border-radius:999px; background:#fff1d2; color:#78560f; font-size:12px; font-weight:700; letter-spacing:.08em; text-transform:uppercase; }
    .overlay-title { margin:0 0 8px; font-size:28px; line-height:1.1; }
    .overlay-copy { margin:0 0 18px; color:var(--muted); font-size:15px; }
    .overlay-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:10px; margin-bottom:16px; }
    .overlay-note { margin:14px 0 0; }

    /* ── Tables ── */
    table { width:100%; border-collapse:collapse; }
    th, td { border-bottom:1px solid var(--line); padding:10px 8px; text-align:left; vertical-align:middle; }
    tr:last-child td { border-bottom:none; }
    th { color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.05em; font-weight:600; }

    /* ── Misc ── */
    .muted { color:var(--muted); }
    .mono { font-family:ui-monospace,SFMono-Regular,Menlo,monospace; }
    .small { font-size:13px; }
    .notice { margin:10px 0 0; font-size:13px; }
    .notice.error { color:var(--danger); }
    .notice.success { color:var(--green); }
    .notice.info { color:var(--blue); }
    .sub-heading { font-size:13px; font-weight:600; color:var(--muted); text-transform:uppercase; letter-spacing:.05em; margin:0 0 8px; }

    @media (max-width:860px) {
      .span-4,.span-6,.span-8 { grid-column:span 12; }
      main { padding:16px 14px; }
      .summary-grid { grid-template-columns:1fr; }
      .update-grid, .overlay-grid { grid-template-columns:1fr; }
      .topbar-gw { display:none; }
      .header-row,.section-head { display:grid; }
    }
  </style>
</head>
<body>

  <!-- ── Sticky topbar ── -->
  <header class="topbar">
    <span class="topbar-brand" data-i18n="appTitle">New Horizons Gateway</span>
    <span class="topbar-gw mono" id="topbar-gw-id"></span>
    <span id="topbar-badge" class="badge">-</span>
    <select id="language-select" style="width:auto;min-height:34px;padding:4px 8px">
      <option value="en">English</option>
      <option value="ja">日本語</option>
      <option value="zh-CN">简体中文</option>
    </select>
  </header>

  <div id="update-required-overlay" class="overlay" hidden>
    <div class="overlay-card">
      <div class="overlay-kicker" data-i18n="updateRequired">Update Required</div>
      <h1 class="overlay-title" data-i18n="overlayTitle">Gateway update required before use</h1>
      <p class="overlay-copy" data-i18n="overlayCopy">The server has reported a newer Gateway version. Update this Gateway now; the current version is locked until the update is applied.</p>
      <div class="overlay-grid">
        <div class="update-card"><span class="stat" data-i18n="current">Current</span><strong id="overlay-current-version">-</strong></div>
        <div class="update-card"><span class="stat" data-i18n="serverLatest">Server Latest</span><strong id="overlay-server-latest">-</strong></div>
        <div class="update-card"><span class="stat" data-i18n="manifestLatest">Manifest Latest</span><strong id="overlay-manifest-latest">-</strong></div>
      </div>
      <div class="button-row">
        <button class="sm" id="overlay-check-update" data-i18n="check">Check</button>
        <button class="sm primary" id="overlay-start-update" data-i18n="updateNow">Update now</button>
        <button class="sm danger" id="overlay-restart-gateway" data-i18n="restart">Restart</button>
      </div>
      <div class="update-banner" id="overlay-update-banner" data-i18n="waitingForUpdateMetadata">Waiting for update metadata.</div>
      <div class="progress-stack">
        <div>
          <div class="progress-head"><span id="overlay-update-progress-phase" data-i18n="waiting">Waiting</span><strong id="overlay-update-progress-label">0%</strong></div>
          <div class="progress-track"><div class="progress-fill" id="overlay-update-progress"></div></div>
        </div>
      </div>
      <pre class="update-notes overlay-note" id="overlay-update-notes" data-i18n="updateNotesPending">Update exists, but release notes are not loaded yet.</pre>
    </div>
  </div>

  <main>

    <!-- ── Setup wizard (3-step, shown when no Gateway ID is configured) ── -->
    <div class="wizard-wrap panel" id="setup-wizard" hidden>
      <div class="wiz-steps">
        <div class="wiz-pip" id="wiz-pip0"></div>
        <div class="wiz-pip" id="wiz-pip1"></div>
        <div class="wiz-pip" id="wiz-pip2"></div>
      </div>

      <!-- Step 1: Gateway ID -->
      <div class="wiz-step active" id="wiz-step-0">
        <p class="wiz-title" data-i18n="w0title">Set up your Gateway</p>
        <p class="wiz-sub" data-i18n="w0sub">Assign a unique ID so devices can identify this gateway on your local network.</p>
        <div class="field" style="margin-bottom:12px">
          <label data-i18n="gatewayId">Gateway ID</label>
          <input id="setup-gateway-id-input" maxlength="64" placeholder="nh-gateway-xxxxxx">
        </div>
        <div class="wiz-actions">
          <button id="setup-auto-gateway-id" data-i18n="autoGenerate">Auto-generate</button>
          <button class="primary" id="wiz-next-0" data-i18n="next">Next →</button>
        </div>
        <p class="notice" id="setup-message"></p>
      </div>

      <!-- Step 2: Upstream server -->
      <div class="wiz-step" id="wiz-step-1">
        <p class="wiz-title" data-i18n="w1title">Upstream server</p>
        <p class="wiz-sub" data-i18n="w1sub">Choose which New Horizons server this gateway relays device data to.</p>
        <div class="field" style="margin-bottom:10px">
          <label data-i18n="mode">Mode</label>
          <select id="wiz-target-mode">
            <option value="production" data-i18n="production">Production</option>
            <option value="local" data-i18n="local">Local</option>
            <option value="manual" data-i18n="manual">Manual URL</option>
          </select>
        </div>
        <div class="field" id="wiz-manual-wrap" style="display:none;margin-bottom:10px">
          <label data-i18n="manualUrl">Manual WS/WSS URL</label>
          <input id="wiz-manual-url" placeholder="ws://127.0.0.1:5051/newhorizons/gateway/ws">
        </div>
        <p class="muted small" id="wiz-url-preview"></p>
        <div class="wiz-actions">
          <button id="wiz-back-1" data-i18n="back">← Back</button>
          <button class="primary" id="wiz-next-1" data-i18n="next">Next →</button>
        </div>
        <p class="notice" id="wiz-msg-1"></p>
      </div>

      <!-- Step 3: Confirm and enable -->
      <div class="wiz-step" id="wiz-step-2">
        <p class="wiz-title" data-i18n="w2title">Enable Gateway</p>
        <p class="wiz-sub" data-i18n="w2sub">Confirm your settings and start the gateway service.</p>
        <div class="wiz-confirm-grid">
          <div class="wiz-card"><span class="muted small" data-i18n="gatewayId">Gateway ID</span><br><strong id="wiz-confirm-id">-</strong></div>
          <div class="wiz-card"><span class="muted small" data-i18n="mode">Mode</span><br><strong id="wiz-confirm-mode">-</strong></div>
        </div>
        <div class="wiz-actions">
          <button id="wiz-back-2" data-i18n="back">← Back</button>
          <button class="primary" id="setup-save-id" data-i18n="enableAndStart">Enable &amp; Start</button>
        </div>
        <p class="notice" id="wiz-msg-2"></p>
      </div>
    </div>

    <!-- ── Main dashboard ── -->
    <div class="grid" id="dashboard-grid" hidden>

      <!-- Status row -->
      <section class="panel span-4">
        <span class="stat" data-i18n="gateway">Gateway</span>
        <strong id="gateway-name">-</strong>
        <p class="muted mono small" id="gateway-id">-</p>
      </section>
      <section class="panel span-4">
        <span class="stat" data-i18n="version">Version</span>
        <strong id="gateway-version">-</strong>
        <p class="muted mono small" id="update-mini">-</p>
      </section>
      <section class="panel span-4">
        <span class="stat" data-i18n="upstream">Upstream</span>
        <span id="upstream-badge" class="badge">-</span>
        <p class="muted mono small" id="upstream-url">-</p>
      </section>

      <!-- ── Gateway Settings ── -->
      <section class="panel span-12" id="nearby-section">
        <h2 data-i18n="gatewaySettings">Gateway Settings</h2>

        <!-- Identity + enable toggle -->
        <div class="toolbar" style="margin-bottom:14px">
          <div class="field">
            <label data-i18n="gatewayId">Gateway ID</label>
            <input id="gateway-id-input" maxlength="64" placeholder="nh-gateway-xxxxxx">
          </div>
          <button id="auto-gateway-id" data-i18n="autoGenerate">Auto-generate</button>
          <div class="sw-row" style="flex:0;white-space:nowrap">
            <label class="sw"><input type="checkbox" id="gateway-enabled"><span class="sw-track"></span></label>
            <span data-i18n="enabledCopy">Start upstream, UDP and FindMe</span>
          </div>
          <button class="primary" id="save-settings" data-i18n="save">Save</button>
        </div>

        <!-- Target server -->
        <div class="stack">
          <div class="toolbar">
            <div class="field narrow">
              <label data-i18n="mode">Mode</label>
              <select id="target-mode">
                <option value="production" data-i18n="production">Production</option>
                <option value="local" data-i18n="local">Local</option>
                <option value="manual" data-i18n="manual">Manual</option>
              </select>
            </div>
            <div class="field">
              <label data-i18n="manualUrl">Manual WS/WSS URL</label>
              <input id="manual-url" placeholder="ws://127.0.0.1:5051/newhorizons/gateway/ws">
            </div>
          </div>
          <div class="summary-grid">
            <div class="summary-card"><span class="stat" data-i18n="connectionMode">Connection mode</span><strong id="target-mode-summary">-</strong></div>
            <div class="summary-card"><span class="stat" data-i18n="effectiveServer">Effective server</span><strong class="mono small" id="effective-server">-</strong></div>
            <div class="summary-card"><span class="stat" data-i18n="upstreamStatus">Upstream status</span><strong id="upstream-summary">-</strong></div>
          </div>
        </div>
        <p class="muted small" style="margin-top:10px">
          <span data-i18n="production">Production</span>: <span class="mono">__PRODUCTION_URL__</span><br>
          <span data-i18n="local">Local</span>: <span class="mono">__LOCAL_URL__</span>
        </p>
        <p class="notice" id="settings-message"></p>
      </section>

      <!-- ── Operations: device management + discovery ── -->
      <section class="panel span-12">
        <div class="section-head">
          <div>
            <h2 data-i18n="operations">Operations</h2>
            <p class="muted small" data-i18n="operationsCopy">Device discovery and management. Nearby devices were seen via FindMe — click Transfer to move them to this gateway.</p>
          </div>
          <div class="button-row">
            <button class="sm secondary" id="refresh-now" data-i18n="refreshNow">Refresh now</button>
            <button class="sm primary" id="discover-nearby" data-i18n="discoverDevices">Discover devices</button>
          </div>
        </div>

        <!-- Summary counts -->
        <div class="summary-grid" style="margin-bottom:18px">
          <div class="summary-card"><span class="stat" data-i18n="servingDevices">Serving Devices</span><strong id="serving-count">0</strong></div>
          <div class="summary-card"><span class="stat" data-i18n="nearbyDevices">Nearby Devices / FindMe Discovery</span><strong id="nearby-count">0</strong></div>
          <div class="summary-card"><span class="stat" data-i18n="claims">Claims</span><strong id="claim-count">0</strong></div>
        </div>

        <!-- Serving devices -->
        <p class="sub-heading" data-i18n="servingDevices">Serving Devices</p>
        <table style="margin-bottom:20px">
          <thead><tr><th data-i18n="device">Device</th><th data-i18n="mode">Mode</th><th>FindMe</th><th>UDP</th><th data-i18n="action">Action</th></tr></thead>
          <tbody id="device-body"></tbody>
        </table>

        <!-- Nearby devices (visible by default) -->
        <div class="section-head" style="margin-bottom:8px">
          <div>
            <p class="sub-heading" data-i18n="nearbyDevices">Nearby Devices / FindMe Discovery</p>
            <p class="muted small" style="margin:0" data-i18n="nearbyCopy">Recent FindMe broadcasts seen by this gateway. Use Transfer only for devices not currently served here.</p>
          </div>
          <button id="nearby-toggle" class="sm" data-i18n="hideNearby">Hide nearby</button>
        </div>
        <div id="nearby-panel">
          <table>
            <thead><tr><th data-i18n="device">Device</th><th data-i18n="mode">Mode</th><th data-i18n="address">Address</th><th data-i18n="state">State</th><th data-i18n="lastSeen">Last seen</th><th data-i18n="action">Action</th></tr></thead>
            <tbody id="nearby-body"></tbody>
          </table>
        </div>

        <!-- Local service stats -->
        <div style="margin-top:16px;display:flex;gap:16px;flex-wrap:wrap;align-items:center">
          <span class="muted small" data-i18n="localServices">Local services</span>
          <strong class="small" id="ports">-</strong>
          <span class="muted small" id="traffic-stats">-</span>
        </div>
      </section>

      <!-- ── Claims ── -->
      <section class="panel span-12">
        <h2 data-i18n="claims">Claims</h2>
        <table>
          <thead><tr><th data-i18n="time">Time</th><th data-i18n="device">Device</th><th>Claim</th><th data-i18n="status">Status</th><th data-i18n="error">Error</th></tr></thead>
          <tbody id="claim-body"></tbody>
        </table>
      </section>

      <!-- ── Update ── -->
      <section class="panel span-12 update-center" id="update-center">
        <div class="section-head">
          <div>
            <h2 data-i18n="updateCenter">Update Center</h2>
            <p class="muted small" id="update-status">-</p>
          </div>
          <div class="button-row">
            <button class="sm" id="check-update" data-i18n="check">Check</button>
            <button class="sm primary" id="start-update" data-i18n="updateNow">Update now</button>
            <button class="sm danger" id="restart-gateway" data-i18n="restart">Restart</button>
          </div>
        </div>
        <div class="update-grid">
          <div class="update-card"><span class="stat" data-i18n="currentVersion">Current Version</span><strong id="current-version-label">-</strong></div>
          <div class="update-card"><span class="stat" data-i18n="serverLatest">Server Latest</span><strong id="server-latest-version">-</strong></div>
          <div class="update-card"><span class="stat" data-i18n="manifestLatest">Manifest Latest</span><strong id="manifest-latest-version">-</strong></div>
          <div class="update-card"><span class="stat" data-i18n="phaseLabel">Phase</span><strong id="update-phase">-</strong></div>
        </div>
        <div class="summary-grid" style="margin-bottom:14px">
          <div class="summary-card"><span class="stat" data-i18n="activeSlot">Active Slot</span><strong id="active-slot-version">-</strong></div>
          <div class="summary-card"><span class="stat" data-i18n="pendingSlot">Pending Slot</span><strong id="pending-slot-version">-</strong></div>
          <div class="summary-card"><span class="stat" data-i18n="bootPhaseLabel">Boot Phase</span><strong id="boot-phase-label">-</strong></div>
          <div class="summary-card"><span class="stat" data-i18n="lastCheck">Last Check</span><strong id="last-update-check">-</strong></div>
          <div class="summary-card"><span class="stat" data-i18n="source">Source</span><strong id="update-source">-</strong></div>
          <div class="summary-card"><span class="stat" data-i18n="autoCheck">Auto Check</span><strong id="auto-check-interval">-</strong></div>
        </div>
        <div class="update-banner" id="update-banner" data-i18n="waitingForUpdateSignal">Waiting for update signal.</div>
        <div class="progress-stack">
          <div>
            <div class="progress-head"><span id="update-progress-phase" data-i18n="waiting">Waiting</span><strong id="update-progress-label">0%</strong></div>
            <div class="progress-track"><div class="progress-fill" id="update-progress"></div></div>
          </div>
        </div>
        <p class="sub-heading" style="margin-top:18px" data-i18n="changelog">Changelog</p>
        <pre class="update-notes" id="update-notes" data-i18n="noChangelogLoaded">No changelog loaded.</pre>
        <p class="notice" id="update-message"></p>
      </section>

    </div>
  </main>

  <script>
    const I18N = {
      en: {
        action:"Action", address:"Address", allow:"Allow", applyUpdate:"Apply update", autoGenerate:"Auto-generate",
        appTitle:"New Horizons Gateway", back:"← Back", checkUpdate:"Check for update",
        claims:"Claims", connectionMode:"Connection mode", denied:"Denied", device:"Device",
        discoverDevices:"Discover devices", downloadUpdate:"Download update",
        effectiveServer:"Effective server", enableAndStart:"Enable & Start",
        enabledCopy:"Start upstream, UDP and FindMe", error:"Error",
        gateway:"Gateway", gatewayId:"Gateway ID", gatewaySettings:"Gateway Settings",
        hideNearby:"Hide nearby", showNearby:"Show nearby",
        language:"Language", lastSeen:"Last seen", localServices:"Local services",
        localServicesCopy:"FindMe / UDP control and data", manualUrl:"Manual WS/WSS URL", mode:"Mode", next:"Next →",
        nearbyCopy:"Recent FindMe broadcasts seen by this gateway. Use Transfer only for devices not currently served here.",
        nearbyDevices:"Nearby Devices / FindMe Discovery",
        noActiveClaims:"No active claims.", noDevices:"No devices served yet.", noNearby:"No nearby FindMe requests yet.",
        offline:"offline", online:"online", operations:"Operations",
        operationsCopy:"Device discovery and management. Nearby devices were seen via FindMe — click Transfer to move them to this gateway.",
        packets:"packets", production:"Production", reject:"Reject",
        refresh:"Refresh", refreshNow:"Refresh now", restartGateway:"Restart Gateway",
        dropped:"dropped", queueDropped:"queue dropped",
        save:"Save", saved:"Saved", serveThisDevice:"Transfer to this gateway",
        serving:"Serving", servingDevices:"Serving Devices",
        setupCopy:"Create a unique Gateway ID before enabling upstream, UDP and FindMe services.",
        setupTitle:"Set up Gateway ID", firstRun:"First setup",
        state:"State", status:"Status", targetServer:"Target Server",
        time:"Time", transfer:"Transfer to this gateway",
        upstream:"Upstream", upstreamSent:"Upstream sent", upstreamStatus:"Upstream status",
        udpIn:"UDP in", update:"Update", updateCenter:"Update Center", updateRequired:"Update Required", updateNow:"Update now", version:"Version",
        check:"Check", restart:"Restart", current:"Current", currentVersion:"Current Version",
        serverLatest:"Server Latest", manifestLatest:"Manifest Latest", phaseLabel:"Phase", activeSlot:"Active Slot",
        pendingSlot:"Pending Slot", bootPhaseLabel:"Boot Phase", lastCheck:"Last Check", source:"Source",
        autoCheck:"Auto Check", waitingForUpdateSignal:"Waiting for update signal.", waitingForUpdateMetadata:"Waiting for update metadata.",
        waiting:"Waiting", changelog:"Changelog", noChangelogLoaded:"No changelog loaded.",
        updateNotesPending:"Update exists, but release notes are not loaded yet.",
        overlayTitle:"Gateway update required before use",
        overlayCopy:"The server has reported a newer Gateway version. Update this Gateway now; the current version is locked until the update is applied.",
        updateStatusSummary:"current {current} / server {server} / manifest {manifest} / boot {boot}",
        updateMiniSummary:"{phase} / server {server} / slot {slot}",
        bannerRequired:"Server requires {version}. Update source: {source}.",
        bannerError:"Update check error: {error}",
        bannerHealthy:"Gateway is on the latest allowed version.",
        overlayBannerReady:"Update {version} is ready to download.",
        overlayBannerNoMandatory:"No mandatory update at the moment.",
        sourceServerWs:"WS server", sourceManifest:"Release manifest",
        phaseIdle:"Idle", phaseChecking:"Checking", phaseChecked:"Checked", phaseDownloading:"Downloading",
        phaseDownloaded:"Downloaded", phaseStaging:"Staging", phaseStaged:"Staged", phaseSwitchPending:"Switch pending",
        phaseRestarting:"Restarting", phaseError:"Error",
        progressChecking:"Checking for update", progressDownloading:"Downloading update", progressDownloaded:"Download complete",
        progressStaging:"Staging inactive slot", progressStaged:"Staging complete", progressSwitching:"Switching slots",
        progressFailed:"Update failed", bootIdle:"Idle", bootPendingSwitch:"Pending switch", bootRolledBack:"Rolled back",
        w0title:"Set up your Gateway",
        w0sub:"Assign a unique ID so devices can identify this gateway on your local network.",
        w1title:"Upstream server",
        w1sub:"Choose which New Horizons server this gateway relays device data to.",
        w2title:"Enable Gateway",
        w2sub:"Confirm your settings and start the gateway service.",
      },
      ja: {
        action:"操作", address:"アドレス", allow:"許可", applyUpdate:"更新を適用", autoGenerate:"自動生成",
        appTitle:"New Horizons Gateway", back:"← 戻る", checkUpdate:"更新を確認",
        claims:"要求", connectionMode:"接続モード", denied:"拒否済み", device:"デバイス",
        discoverDevices:"デバイスを検出", downloadUpdate:"更新をダウンロード",
        effectiveServer:"実際の接続先", enableAndStart:"有効化して開始",
        enabledCopy:"上流接続、UDP、FindMeを開始", error:"エラー",
        gateway:"ゲートウェイ", gatewayId:"Gateway ID", gatewaySettings:"ゲートウェイ設定",
        hideNearby:"非表示", showNearby:"表示",
        language:"言語", lastSeen:"最終確認", localServices:"ローカルサービス",
        localServicesCopy:"FindMe / UDP制御とデータ", manualUrl:"手動 WS/WSS URL", mode:"モード", next:"次へ →",
        nearbyCopy:"このゲートウェイが受信した最近のFindMeブロードキャストです。ここで未提供のデバイスだけ転送できます。",
        nearbyDevices:"近くのデバイス / FindMe 検出",
        noActiveClaims:"有効な要求はありません。", noDevices:"提供中のデバイスはありません。", noNearby:"近くのFindMe要求はありません。",
        offline:"オフライン", online:"オンライン", operations:"操作",
        operationsCopy:"デバイスの検出と管理。「近くにある」デバイスはFindMe経由で確認済み——転送ボタンでこのゲートウェイに移動できます。",
        packets:"パケット", production:"本番", reject:"拒否",
        refresh:"更新", refreshNow:"今すぐ更新", restartGateway:"Gatewayを再起動",
        dropped:"破棄", queueDropped:"キュー破棄",
        save:"保存", saved:"保存しました", serveThisDevice:"このゲートウェイに転送",
        serving:"提供中", servingDevices:"提供中のデバイス",
        setupCopy:"上流接続、UDP、FindMeサービスを有効にする前に、一意なGateway IDを設定してください。",
        setupTitle:"Gateway IDを設定", firstRun:"初回設定",
        state:"状態", status:"状態", targetServer:"接続先サーバー",
        time:"時刻", transfer:"このゲートウェイに転送",
        upstream:"上流接続", upstreamSent:"上流送信", upstreamStatus:"上流状態",
        udpIn:"UDP入力", update:"更新", updateCenter:"更新センター", updateRequired:"更新必須", updateNow:"今すぐ更新", version:"バージョン",
        check:"確認", restart:"再起動", current:"現在", currentVersion:"現在のバージョン",
        serverLatest:"サーバー最新", manifestLatest:"マニフェスト最新", phaseLabel:"フェーズ", activeSlot:"アクティブスロット",
        pendingSlot:"保留スロット", bootPhaseLabel:"起動フェーズ", lastCheck:"最終確認", source:"ソース",
        autoCheck:"自動確認", waitingForUpdateSignal:"更新通知を待機しています。", waitingForUpdateMetadata:"更新メタデータを待機しています。",
        waiting:"待機中", changelog:"更新履歴", noChangelogLoaded:"更新履歴はまだ読み込まれていません。",
        updateNotesPending:"更新はありますが、リリースノートはまだ読み込まれていません。",
        overlayTitle:"使用前に Gateway を更新してください",
        overlayCopy:"サーバーがより新しい Gateway バージョンを報告しました。今すぐこの Gateway を更新してください。更新が適用されるまで現在のバージョンはロックされます。",
        updateStatusSummary:"現在 {current} / サーバー {server} / マニフェスト {manifest} / 起動 {boot}",
        updateMiniSummary:"{phase} / サーバー {server} / スロット {slot}",
        bannerRequired:"サーバーは {version} を要求しています。更新ソース: {source}。",
        bannerError:"更新確認エラー: {error}",
        bannerHealthy:"Gateway は許可された最新バージョンで動作しています。",
        overlayBannerReady:"更新 {version} をダウンロードできます。",
        overlayBannerNoMandatory:"現在、必須更新はありません。",
        sourceServerWs:"WS サーバー", sourceManifest:"リリースマニフェスト",
        phaseIdle:"待機", phaseChecking:"確認中", phaseChecked:"確認済み", phaseDownloading:"ダウンロード中",
        phaseDownloaded:"ダウンロード完了", phaseStaging:"ステージング中", phaseStaged:"ステージング完了", phaseSwitchPending:"切り替え待機",
        phaseRestarting:"再起動中", phaseError:"エラー",
        progressChecking:"更新を確認中", progressDownloading:"更新をダウンロード中", progressDownloaded:"ダウンロード完了",
        progressStaging:"非アクティブスロットをステージング中", progressStaged:"ステージング完了", progressSwitching:"スロットを切り替え中",
        progressFailed:"更新に失敗しました", bootIdle:"待機", bootPendingSwitch:"切り替え待機", bootRolledBack:"ロールバック済み",
        w0title:"ゲートウェイのセットアップ",
        w0sub:"ネットワーク上でこのゲートウェイを識別する固有のIDを割り当てます。",
        w1title:"上流サーバー",
        w1sub:"このゲートウェイが接続するサーバーを選択します。",
        w2title:"ゲートウェイを有効化",
        w2sub:"設定を確認してサービスを開始します。",
      },
      "zh-CN": {
        action:"操作", address:"地址", allow:"允许", applyUpdate:"应用更新", autoGenerate:"自动生成",
        appTitle:"New Horizons Gateway", back:"← 返回", checkUpdate:"检查更新",
        claims:"Claims", connectionMode:"连接模式", denied:"已拒绝", device:"设备",
        discoverDevices:"发现设备", downloadUpdate:"下载更新",
        effectiveServer:"实际服务器", enableAndStart:"启用并启动",
        enabledCopy:"启动上游、UDP 和 FindMe", error:"错误",
        gateway:"网关", gatewayId:"Gateway ID", gatewaySettings:"网关设置",
        hideNearby:"隐藏附近设备", showNearby:"显示附近设备",
        language:"语言", lastSeen:"最后发现", localServices:"本地服务",
        localServicesCopy:"FindMe / UDP 控制与数据", manualUrl:"手动 WS/WSS URL", mode:"模式", next:"下一步 →",
        nearbyCopy:"此网关最近收到的 FindMe 广播。仅对当前未由此网关服务的设备使用“转移”。",
        nearbyDevices:"附近设备 / FindMe 发现",
        noActiveClaims:"当前没有活动 Claims。", noDevices:"当前没有服务中的设备。", noNearby:"尚未收到附近的 FindMe 请求。",
        offline:"离线", online:"在线", operations:"操作",
        operationsCopy:"设备发现与管理。附近设备通过 FindMe 被看到后，可点击“转移”将其切换到此网关。",
        packets:"数据包", production:"生产环境", reject:"拒绝",
        refresh:"刷新", refreshNow:"立即刷新", restartGateway:"重启 Gateway",
        dropped:"丢弃", queueDropped:"队列丢弃",
        save:"保存", saved:"已保存", serveThisDevice:"转移到此网关",
        serving:"服务中", servingDevices:"服务中的设备",
        setupCopy:"在启用上游、UDP 和 FindMe 服务之前，请先创建唯一的 Gateway ID。",
        setupTitle:"设置 Gateway ID", firstRun:"首次设置",
        state:"状态", status:"状态", targetServer:"目标服务器",
        time:"时间", transfer:"转移到此网关",
        upstream:"上游", upstreamSent:"上游已发送", upstreamStatus:"上游状态",
        udpIn:"UDP 输入", update:"更新", updateCenter:"更新中心", updateRequired:"必须更新", updateNow:"立即更新", version:"版本",
        check:"检查", restart:"重启", current:"当前", currentVersion:"当前版本",
        serverLatest:"服务器最新版本", manifestLatest:"清单最新版本", phaseLabel:"阶段", activeSlot:"活动槽位",
        pendingSlot:"待切换槽位", bootPhaseLabel:"启动阶段", lastCheck:"最后检查", source:"来源",
        autoCheck:"自动检查", waitingForUpdateSignal:"等待更新信号。", waitingForUpdateMetadata:"等待更新元数据。",
        waiting:"等待中", changelog:"更新日志", noChangelogLoaded:"尚未加载更新日志。",
        updateNotesPending:"发现更新，但更新说明尚未加载。",
        overlayTitle:"使用前需要更新 Gateway",
        overlayCopy:"服务器报告了更高版本的 Gateway。请立即更新此 Gateway；在更新完成前，当前版本将被锁定。",
        updateStatusSummary:"当前 {current} / 服务器 {server} / 清单 {manifest} / 启动 {boot}",
        updateMiniSummary:"{phase} / 服务器 {server} / 槽位 {slot}",
        bannerRequired:"服务器要求版本 {version}。更新来源：{source}。",
        bannerError:"检查更新出错：{error}",
        bannerHealthy:"Gateway 当前已运行在允许使用的最新版本。",
        overlayBannerReady:"更新 {version} 已可下载。",
        overlayBannerNoMandatory:"当前没有强制更新。",
        sourceServerWs:"WS 服务器", sourceManifest:"发布清单",
        phaseIdle:"空闲", phaseChecking:"检查中", phaseChecked:"已检查", phaseDownloading:"下载中",
        phaseDownloaded:"下载完成", phaseStaging:"准备中", phaseStaged:"准备完成", phaseSwitchPending:"等待切换",
        phaseRestarting:"重启中", phaseError:"错误",
        progressChecking:"正在检查更新", progressDownloading:"正在下载更新", progressDownloaded:"下载完成",
        progressStaging:"正在准备非活动槽位", progressStaged:"准备完成", progressSwitching:"正在切换槽位",
        progressFailed:"更新失败", bootIdle:"空闲", bootPendingSwitch:"等待切换", bootRolledBack:"已回滚",
        w0title:"设置你的 Gateway",
        w0sub:"分配一个唯一 ID，让设备能在本地网络中识别此 Gateway。",
        w1title:"上游服务器",
        w1sub:"选择此 Gateway 要把设备数据转发到哪个 New Horizons 服务器。",
        w2title:"启用 Gateway",
        w2sub:"确认设置并启动 Gateway 服务。",
      },
    };

    function normalizeLanguage(value) {
      const input = String(value || "").trim().toLowerCase();
      if (input === "ja" || input.startsWith("ja-")) return "ja";
      if (input === "zh" || input === "zh-cn" || input === "zh-hans" || input.startsWith("zh-cn") || input.startsWith("zh-hans")) return "zh-CN";
      return "en";
    }

    function detectBrowserLanguage() {
      const candidates = Array.isArray(navigator.languages) && navigator.languages.length
        ? navigator.languages
        : [navigator.language];
      for (const candidate of candidates) {
        const normalized = normalizeLanguage(candidate);
        if (I18N[normalized]) return normalized;
      }
      return "en";
    }

    let language = normalizeLanguage(localStorage.getItem("newhorizons-gateway-language")) || detectBrowserLanguage();
    if (!localStorage.getItem("newhorizons-gateway-language")) {
      language = detectBrowserLanguage();
    }
    const PRODUCTION_URL = "__PRODUCTION_URL__";
    const LOCAL_URL = "__LOCAL_URL__";
    let showNearby = true;
    let targetSettingsDirty = false;
    let setupGatewayIdSuggested = false;
    let wizardStep = 0;
    let updateLocked = false;

    function tr(key) { return (I18N[language] && I18N[language][key]) || I18N.en[key] || key; }

    function fmt(key, values = {}) {
      let template = tr(key);
      Object.entries(values).forEach(([name, value]) => {
        template = template.replaceAll(`{${name}}`, String(value ?? "-"));
      });
      return template;
    }

    function localizeSource(value) {
      const source = String(value || "").trim();
      if (source === "server_ws") return tr("sourceServerWs");
      if (source === "manifest") return tr("sourceManifest");
      return source || "-";
    }

    function localizePhaseCode(value) {
      const phase = String(value || "").trim();
      const keyMap = {
        idle: "phaseIdle",
        checking: "phaseChecking",
        checked: "phaseChecked",
        downloading: "phaseDownloading",
        downloaded: "phaseDownloaded",
        staging: "phaseStaging",
        staged: "phaseStaged",
        switch_pending: "phaseSwitchPending",
        restarting: "phaseRestarting",
        error: "phaseError",
      };
      return keyMap[phase] ? tr(keyMap[phase]) : (phase || "-");
    }

    function localizeProgressPhase(value) {
      const phase = String(value || "").trim();
      const keyMap = {
        idle: "waiting",
        checking: "progressChecking",
        checked: "phaseChecked",
        downloading: "progressDownloading",
        downloaded: "progressDownloaded",
        staging: "progressStaging",
        staged: "progressStaged",
        switch_pending: "progressSwitching",
        restarting: "phaseRestarting",
        error: "progressFailed",
      };
      return keyMap[phase] ? tr(keyMap[phase]) : (phase || tr("waiting"));
    }

    function localizeBootPhase(value) {
      const phase = String(value || "").trim();
      const keyMap = {
        idle: "bootIdle",
        pending_switch: "bootPendingSwitch",
        rolled_back: "bootRolledBack",
      };
      return keyMap[phase] ? tr(keyMap[phase]) : (phase || "-");
    }

    function updateNearbyToggleLabel() {
      const node = document.getElementById("nearby-toggle");
      if (node) node.textContent = showNearby ? tr("hideNearby") : tr("showNearby");
    }

    function applyI18n() {
      document.documentElement.lang = language;
      document.getElementById("language-select").value = language;
      document.querySelectorAll("[data-i18n]").forEach((node) => { node.textContent = tr(node.getAttribute("data-i18n")); });
      updateNearbyToggleLabel();
    }

    function esc(value) {
      return String(value ?? "").replace(/[&<>"']/g, (ch) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
    }

    async function api(path, options) {
      const res = await fetch(path, options);
      const payload = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(payload.error || payload.message || res.statusText);
      return payload;
    }

    function text(id, value) {
      const el = document.getElementById(id);
      if (el) el.textContent = value || "-";
    }

    function notice(id, message, cls = "") {
      const node = document.getElementById(id);
      if (!node) return;
      node.textContent = message || "";
      node.className = `notice ${cls}`.trim();
    }

    function setPre(id, value) {
      const node = document.getElementById(id);
      if (node) node.textContent = value || "";
    }

    function setProgress(id, labelId, pct) {
      const value = Math.max(0, Math.min(100, Number(pct || 0)));
      const fill = document.getElementById(id);
      const label = document.getElementById(labelId);
      if (fill) fill.style.width = `${value}%`;
      if (label) label.textContent = `${value}%`;
    }

    function formatIsoTime(value) {
      if (!value) return "-";
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return String(value);
      return date.toLocaleString();
    }

    function setGatewayLock(locked) {
      updateLocked = !!locked;
      const overlay = document.getElementById("update-required-overlay");
      if (overlay) overlay.hidden = !updateLocked;
      [
        "setup-auto-gateway-id",
        "wiz-next-0",
        "wiz-next-1",
        "wiz-back-1",
        "wiz-back-2",
        "setup-save-id",
        "auto-gateway-id",
        "save-settings",
        "refresh-now",
        "discover-nearby",
        "nearby-toggle",
        "language-select",
      ].forEach((id) => {
        const node = document.getElementById(id);
        if (node) node.disabled = updateLocked;
      });
    }

    function resolveTargetServerUrl() {
      const mode = String(document.getElementById("target-mode").value || "production");
      if (mode === "local") return LOCAL_URL;
      if (mode === "manual") return String(document.getElementById("manual-url").value || "").trim() || LOCAL_URL;
      return PRODUCTION_URL;
    }

    function updateTargetServerSummary() {
      const mode = String(document.getElementById("target-mode").value || "production");
      text("target-mode-summary", tr(mode));
      text("effective-server", resolveTargetServerUrl());
    }

    function syncTargetSettings(config) {
      if (targetSettingsDirty) return;
      document.getElementById("target-mode").value = config.target_mode || "production";
      document.getElementById("manual-url").value = config.manual_url || "";
      document.getElementById("gateway-id-input").value = config.gateway_id || "";
      document.getElementById("gateway-enabled").checked = !!config.enabled;
    }

    // ── Wizard ──────────────────────────────────────────────────────────
    function wizSetStep(step) {
      wizardStep = step;
      [0, 1, 2].forEach((i) => {
        const s = document.getElementById(`wiz-step-${i}`);
        if (s) s.className = `wiz-step${i === step ? " active" : ""}`;
        const p = document.getElementById(`wiz-pip${i}`);
        if (p) p.className = `wiz-pip${i === step ? " active" : i < step ? " done" : ""}`;
      });
      if (step === 2) {
        text("wiz-confirm-id", document.getElementById("setup-gateway-id-input").value || "-");
        const mode = document.getElementById("wiz-target-mode").value;
        text("wiz-confirm-mode", tr(mode));
      }
    }

    function wizResolveUrl(mode, manual) {
      if (mode === "local") return LOCAL_URL;
      if (mode === "manual") return String(manual || "").trim() || LOCAL_URL;
      return PRODUCTION_URL;
    }

    document.getElementById("setup-auto-gateway-id").addEventListener("click", async () => {
      try {
        const payload = await api("/api/gateway-id/suggest", { method: "POST" });
        document.getElementById("setup-gateway-id-input").value = payload.gateway_id || "";
        setupGatewayIdSuggested = true;
      } catch (error) {
        notice("setup-message", error.message || String(error), "error");
      }
    });

    document.getElementById("wiz-next-0").addEventListener("click", () => {
      const id = String(document.getElementById("setup-gateway-id-input").value || "").trim();
      if (!id) { notice("setup-message", tr("gatewayId") + " required", "error"); return; }
      notice("setup-message", "");
      wizSetStep(1);
    });

    document.getElementById("wiz-target-mode").addEventListener("change", () => {
      const mode = document.getElementById("wiz-target-mode").value;
      document.getElementById("wiz-manual-wrap").style.display = mode === "manual" ? "" : "none";
      text("wiz-url-preview", wizResolveUrl(mode, document.getElementById("wiz-manual-url").value));
    });
    document.getElementById("wiz-manual-url").addEventListener("input", () => {
      const mode = document.getElementById("wiz-target-mode").value;
      text("wiz-url-preview", wizResolveUrl(mode, document.getElementById("wiz-manual-url").value));
    });

    document.getElementById("wiz-back-1").addEventListener("click", () => wizSetStep(0));
    document.getElementById("wiz-next-1").addEventListener("click", () => { notice("wiz-msg-1", ""); wizSetStep(2); });
    document.getElementById("wiz-back-2").addEventListener("click", () => wizSetStep(1));

    document.getElementById("setup-save-id").addEventListener("click", async () => {
      notice("wiz-msg-2", "");
      const btn = document.getElementById("setup-save-id");
      btn.disabled = true;
      try {
        const mode = document.getElementById("wiz-target-mode").value;
        const manual = String(document.getElementById("wiz-manual-url").value || "").trim();
        await api("/api/settings", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            gateway_id: String(document.getElementById("setup-gateway-id-input").value || "").trim(),
            target_mode: mode, manual_url: manual, enabled: true,
          }),
        });
        targetSettingsDirty = false;
        refresh();
      } catch (error) {
        notice("wiz-msg-2", error.message || String(error), "error");
      } finally {
        btn.disabled = false;
      }
    });

    // ── Settings ────────────────────────────────────────────────────────
    document.getElementById("save-settings").addEventListener("click", async () => {
      notice("settings-message", "");
      try {
        await api("/api/settings", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            target_mode: document.getElementById("target-mode").value,
            manual_url: document.getElementById("manual-url").value,
            gateway_id: document.getElementById("gateway-id-input").value,
            enabled: document.getElementById("gateway-enabled").checked,
          }),
        });
        targetSettingsDirty = false;
        notice("settings-message", tr("saved"), "success");
        refresh();
      } catch (error) {
        notice("settings-message", error.message || String(error), "error");
      }
    });

    document.getElementById("auto-gateway-id").addEventListener("click", async () => {
      try {
        const payload = await api("/api/gateway-id/suggest", { method: "POST" });
        document.getElementById("gateway-id-input").value = payload.gateway_id || "";
        targetSettingsDirty = true;
      } catch (error) {
        notice("settings-message", error.message || String(error), "error");
      }
    });

    document.getElementById("target-mode").addEventListener("change", () => { targetSettingsDirty = true; updateTargetServerSummary(); });
    document.getElementById("manual-url").addEventListener("input", () => { targetSettingsDirty = true; updateTargetServerSummary(); });
    document.getElementById("gateway-id-input").addEventListener("input", () => { targetSettingsDirty = true; });
    document.getElementById("gateway-enabled").addEventListener("change", () => { targetSettingsDirty = true; });

    // ── Update ───────────────────────────────────────────────────────────
    function renderUpdate(state) {
      const current = state.current_version || "-";
      const latest = state.latest_version || "-";
      const serverLatest = state.latest_gateway_version || "-";
      const phase = state.phase || "idle";
      const source = state.update_signal_source || "-";
      const sourceText = localizeSource(source);
      const phaseText = localizePhaseCode(phase);
      const activeSlot = state.active_slot || "-";
      const pendingSlot = state.pending_slot || "-";
      const bootPhase = state.boot_phase || "idle";
      const bootPhaseText = localizeBootPhase(bootPhase);
      const rollbackReason = state.rollback_reason || "";
      const healthyUpdateCenter = !state.required_update
        && !state.last_error
        && (!serverLatest || serverLatest === "-" || serverLatest === current);
      const notes = state.notes_markdown
        || (state.required_update
          ? tr("updateNotesPending")
          : tr("noChangelogLoaded"));
      text("gateway-version", current);
      text("current-version-label", current);
      text("server-latest-version", serverLatest);
      text("manifest-latest-version", latest);
      text("update-phase", phaseText);
      text("active-slot-version", `${activeSlot} / ${current}`);
      text("pending-slot-version", pendingSlot ? `${pendingSlot} / ${state.target_version || "-"}` : "-");
      text("boot-phase-label", rollbackReason ? `${bootPhaseText} (${rollbackReason})` : bootPhaseText);
      text("last-update-check", formatIsoTime(state.last_checked_at));
      text("update-source", sourceText);
      text("auto-check-interval", `${Number(state.auto_check_interval_sec || 0)}s`);
      text("overlay-current-version", current);
      text("overlay-server-latest", serverLatest);
      text("overlay-manifest-latest", latest);
      text("update-mini", fmt("updateMiniSummary", { phase: phaseText, server: serverLatest, slot: activeSlot }));
      text("update-status", fmt("updateStatusSummary", { current, server: serverLatest, manifest: latest, boot: bootPhaseText }));
      text("update-progress-phase", localizeProgressPhase(phase));
      text("overlay-update-progress-phase", localizeProgressPhase(phase));
      setProgress("update-progress", "update-progress-label", state.progress_pct);
      setProgress("overlay-update-progress", "overlay-update-progress-label", state.progress_pct);
      setPre("update-notes", notes);
      setPre("overlay-update-notes", notes);
      const banner = state.required_update
        ? fmt("bannerRequired", { version: serverLatest, source: sourceText })
        : (state.last_error ? fmt("bannerError", { error: state.last_error }) : tr("bannerHealthy"));
      const overlayBanner = state.required_update
        ? (state.notes_markdown ? fmt("overlayBannerReady", { version: serverLatest }) : tr("updateNotesPending"))
        : tr("overlayBannerNoMandatory");
      const bannerNode = document.getElementById("update-banner");
      const overlayNode = document.getElementById("overlay-update-banner");
      const updateCenter = document.getElementById("update-center");
      if (updateCenter) updateCenter.className = `panel span-12 update-center${healthyUpdateCenter ? " ok" : ""}`;
      if (bannerNode) {
        bannerNode.textContent = banner;
        bannerNode.className = `update-banner${healthyUpdateCenter ? " ok" : state.last_error && !state.required_update ? " error" : ""}`;
      }
      if (overlayNode) {
        overlayNode.textContent = overlayBanner;
        overlayNode.className = `update-banner${state.last_error && !state.notes_markdown ? " error" : ""}`;
      }
      const canStartUpdate = !state.busy && !!(state.required_update || state.update_available);
      document.getElementById("start-update").disabled = !canStartUpdate;
      document.getElementById("overlay-start-update").disabled = !canStartUpdate;
      document.getElementById("restart-gateway").disabled = !!state.busy || !state.restart_required;
      document.getElementById("overlay-restart-gateway").disabled = !!state.busy || !state.restart_required;
      setGatewayLock(state.required_update);
    }

    async function updateAction(path) {
      notice("update-message", "");
      try {
        const payload = await api(path, { method: "POST" });
        renderUpdate(payload.update_state || payload);
        notice("update-message", localizePhaseCode((payload.update_state || payload).phase || "checked"), "success");
      } catch (error) {
        notice("update-message", error.message || String(error), "error");
      }
    }

    document.getElementById("check-update").addEventListener("click", () => updateAction("/api/update/check"));
    document.getElementById("start-update").addEventListener("click", () => updateAction("/api/update/start"));
    document.getElementById("restart-gateway").addEventListener("click", () => updateAction("/api/update/restart"));
    document.getElementById("overlay-check-update").addEventListener("click", () => updateAction("/api/update/check"));
    document.getElementById("overlay-start-update").addEventListener("click", () => updateAction("/api/update/start"));
    document.getElementById("overlay-restart-gateway").addEventListener("click", () => updateAction("/api/update/restart"));

    // ── Device action clicks ─────────────────────────────────────────────
    document.addEventListener("click", async (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (updateLocked) return;
      const reject = target.getAttribute("data-reject");
      const allow = target.getAttribute("data-allow");
      const serve = target.getAttribute("data-serve");
      if (reject) {
        target.disabled = true;
        await api(`/api/devices/${encodeURIComponent(reject)}/reject`, { method: "POST" }).catch(() => { target.disabled = false; });
      }
      if (allow) {
        target.disabled = true;
        await api(`/api/devices/${encodeURIComponent(allow)}/allow`, { method: "POST" }).catch(() => { target.disabled = false; });
      }
      if (serve) {
        target.disabled = true;
        const orig = target.textContent;
        target.textContent = "…";
        await api(`/api/devices/${encodeURIComponent(serve)}/serve`, { method: "POST" }).catch(() => {
          target.textContent = orig;
          target.disabled = false;
        });
      }
      if (reject || allow || serve) refresh();
    });

    document.getElementById("refresh-now").addEventListener("click", () => refresh());

    document.getElementById("discover-nearby").addEventListener("click", async () => {
      showNearby = true;
      await api("/api/discover", { method: "POST" }).catch(() => {});
      await refresh();
      const panel = document.getElementById("nearby-section");
      if (panel) panel.scrollIntoView({ block: "start", behavior: "smooth" });
    });

    document.getElementById("nearby-toggle").addEventListener("click", () => {
      showNearby = !showNearby;
      refresh();
    });

    document.getElementById("language-select").addEventListener("change", (event) => {
      language = normalizeLanguage(event.target.value);
      if (!I18N[language]) language = "en";
      localStorage.setItem("newhorizons-gateway-language", language);
      refresh();
    });

    // ── Main refresh ──────────────────────────────────────────────────────
    async function refresh() {
      applyI18n();
      const data = await api("/api/status");
      const hasGatewayId = !!String(data.config.gateway_id || "").trim();
      document.getElementById("setup-wizard").hidden = hasGatewayId;
      document.getElementById("dashboard-grid").hidden = !hasGatewayId;

      if (hasGatewayId) { setupGatewayIdSuggested = false; wizardStep = 0; }

      if (!hasGatewayId && !setupGatewayIdSuggested) {
        setupGatewayIdSuggested = true;
        try {
          const payload = await api("/api/gateway-id/suggest", { method: "POST" });
          if (!String(document.getElementById("setup-gateway-id-input").value || "").trim()) {
            document.getElementById("setup-gateway-id-input").value = payload.gateway_id || "";
          }
        } catch (error) {
          notice("setup-message", error.message || String(error), "error");
        }
      }

      if (!hasGatewayId) { wizSetStep(wizardStep); return; }

      // Topbar
      text("topbar-gw-id", data.config.gateway_id);
      const isEnabled = !!data.config.enabled;
      const isConnected = isEnabled && !!data.upstream.connected;
      const topbarBadge = document.getElementById("topbar-badge");
      topbarBadge.textContent = !isEnabled ? "disabled" : (isConnected ? tr("online") : tr("offline"));
      topbarBadge.className = `badge${!isEnabled ? " warn" : isConnected ? " ok" : " err"}`;

      // Stat panels
      text("gateway-name", data.config.gateway_name);
      text("gateway-id", data.config.gateway_id);
      text("upstream-url", data.upstream.server_url);
      const upBadge = document.getElementById("upstream-badge");
      upBadge.textContent = !isEnabled ? "disabled" : (isConnected ? tr("online") : tr("offline"));
      upBadge.className = `badge${!isEnabled ? " warn" : isConnected ? " ok" : " err"}`;

      text("upstream-summary", !isEnabled ? "disabled" : (isConnected ? tr("online") : tr("offline")));
      text("ports", `FindMe ${data.config.listen_discovery_port} / UDP ${data.config.listen_udp_port}`);
      text("traffic-stats", `${tr("udpIn")} ${Number(data.upstream.udp_in_fps || 0)}/s · ${tr("upstreamSent")} ${Number(data.upstream.upstream_sent_fps || 0)}/s · ${tr("queueDropped")} ${Number(data.upstream.data_queue_dropped || 0)}`);

      syncTargetSettings(data.config || {});
      updateTargetServerSummary();
      renderUpdate(data.update_state || {});

      // Counts
      const servingDevices = (data.state.devices || []).filter((item) => item.connected);
      text("serving-count", String(servingDevices.length));
      text("nearby-count", String((data.state.nearby_devices || []).length));
      text("claim-count", String((data.state.claims || []).length));

      // Serving devices table
      const body = document.getElementById("device-body");
      body.innerHTML = "";
      for (const item of servingDevices) {
        const row = document.createElement("tr");
        const action = updateLocked
          ? `<button class="sm" disabled>Locked</button>`
          : (item.denied
            ? `<button class="sm" data-allow="${esc(item.device_uid)}">${tr("allow")}</button>`
            : `<button class="sm danger" data-reject="${esc(item.device_uid)}">${tr("reject")}</button>`);
        row.innerHTML = `<td><strong>${esc(item.device_name || item.device_uid)}</strong><br><span class="muted mono small">${esc(item.device_uid)}</span></td><td class="small">${esc(item.mode || "-")}</td><td class="small">${esc(item.findme_state || "attached")}<br><span class="muted">${esc(item.wifi_rssi ?? "")}</span></td><td class="small">${Number(item.udp_packets || 0)} ${tr("packets")}<br><span class="muted">${Number(item.udp_dropped || 0)} ${tr("dropped")}</span></td><td>${action}</td>`;
        body.appendChild(row);
      }
      if (!servingDevices.length) body.innerHTML = `<tr><td colspan="5" class="muted">${tr("noDevices")}</td></tr>`;

      // Nearby devices table
      document.getElementById("nearby-panel").hidden = !showNearby;
      updateNearbyToggleLabel();
      const nbody = document.getElementById("nearby-body");
      nbody.innerHTML = "";
      for (const item of data.state.nearby_devices || []) {
        const row = document.createElement("tr");
        const stateLabel = item.serving ? tr("serving") : (item.denied ? tr("denied") : esc(item.findme_state || item.findme_reason || "-"));
        let action = "";
        if (updateLocked) {
          action = `<button class="sm" disabled>Locked</button>`;
        } else if (item.serving) {
          action = `<span class="badge ok">${tr("serving")}</span>`;
        } else if (item.denied) {
          action = `<button class="sm" data-allow="${esc(item.device_uid)}">${tr("allow")}</button>`;
        } else if (data.upstream.connected) {
          action = `<button class="sm secondary" data-serve="${esc(item.device_uid)}">${tr("serveThisDevice")}</button>`;
        } else {
          action = `<button class="sm" disabled title="${tr("upstreamStatus")}: ${tr("offline")}">${tr("serveThisDevice")}</button>`;
        }
        row.innerHTML = `<td><strong>${esc(item.device_name || item.device_uid)}</strong><br><span class="mono muted small">${esc(item.device_uid || "-")}</span></td><td class="small">${esc(item.mode || "-")}</td><td class="small mono">${esc(item.addr || "-")}</td><td class="small">${stateLabel}</td><td class="small muted">${esc(item.last_findme_at || "-")}</td><td>${action}</td>`;
        nbody.appendChild(row);
      }
      if (!(data.state.nearby_devices || []).length) nbody.innerHTML = `<tr><td colspan="6" class="muted">${tr("noNearby")}</td></tr>`;

      // Claims table
      const cbody = document.getElementById("claim-body");
      cbody.innerHTML = "";
      for (const item of data.state.claims || []) {
        const row = document.createElement("tr");
        row.innerHTML = `<td class="small">${esc(item.updated_at || item.requested_at || "-")}</td><td><span class="mono small">${esc(item.device_uid || "-")}</span></td><td><span class="mono small">${esc(item.claim_id || "-")}</span></td><td class="small">${esc(item.state || "-")}</td><td class="small muted">${esc(item.last_error || "")}</td>`;
        cbody.appendChild(row);
      }
      if (!(data.state.claims || []).length) cbody.innerHTML = `<tr><td colspan="5" class="muted">${tr("noActiveClaims")}</td></tr>`;
    }

    applyI18n();
    refresh();
    setInterval(refresh, 2000);
  </script>
</body>
</html>""".replace("__PRODUCTION_URL__", PRODUCTION_URL).replace("__LOCAL_URL__", LOCAL_URL)


class GatewayWebServer:
    def __init__(
        self,
        host: str,
        port: int,
        config_store: GatewayConfigStore,
        state: GatewayState,
        upstream: Any,
        udp_control: Any | None = None,
        *,
        discovery: Any | None = None,
        on_config_saved: ConfigCallback | None = None,
        update_manager: GatewayUpdateManager | None = None,
    ) -> None:
        self.host = host
        self.port = int(port)
        self.config_store = config_store
        self.state = state
        self.upstream = upstream
        self.udp_control = udp_control
        self.discovery = discovery
        self.on_config_saved = on_config_saved
        self.update_manager = update_manager or GatewayUpdateManager()
        self.app = self._make_app()
        self._server: Any = None
        self._thread: threading.Thread | None = None

    def _make_app(self) -> Flask:
        app = Flask(__name__)

        def update_required_response() -> Any:
            return jsonify({"ok": False, "error": "update_required"}), 409

        def ensure_not_locked() -> Any | None:
            if self.update_manager.state().get("required_update"):
                return update_required_response()
            return None

        @app.get("/")
        def index() -> str:
            return PAGE

        @app.get("/api/status")
        def status() -> Any:
            config = self.config_store.snapshot()
            update_state = self.update_manager.maybe_refresh()
            return jsonify({
                "config": self._public_config(config),
                "version": __version__,
                "upstream": self.upstream.status(),
                "udp_control": self.udp_control.snapshot() if self.udp_control is not None else {},
                "state": self.state.snapshot(config.get("denied_devices", [])),
                "update_state": update_state,
            })

        @app.post("/api/settings")
        def settings() -> Any:
            locked = ensure_not_locked()
            if locked is not None:
                return locked
            body = request.get_json(silent=True) or {}
            try:
                patch = {
                    "target_mode": body.get("target_mode", "production"),
                    "manual_url": body.get("manual_url", ""),
                    "gateway_id": body.get("gateway_id", ""),
                    "enabled": bool(body.get("enabled", False)),
                }
                if patch["enabled"]:
                    validate_gateway_id(patch["gateway_id"])
                config = self.config_store.save(patch)
            except ValueError as exc:
                return jsonify({"ok": False, "error": str(exc)}), 400
            if self.on_config_saved is not None:
                self.on_config_saved(config)
            else:
                self.upstream.gateway_id = str(config.get("gateway_id") or "")
                self.upstream.update_server(str(config["server_url"]), "")
            return jsonify({"ok": True, "config": self._public_config(config)})

        @app.post("/api/gateway-id/suggest")
        def suggest_gateway_id() -> Any:
            try:
                return jsonify({"gateway_id": self._request_gateway_id_suggestion()})
            except Exception as exc:
                return jsonify({"ok": False, "error": str(exc)}), 503

        @app.post("/api/update/check")
        def update_check() -> Any:
            return jsonify({"ok": True, "update_state": self.update_manager.check()})

        @app.post("/api/update/start")
        def update_start() -> Any:
            return jsonify({"ok": True, "update_state": self.update_manager.start_update()})

        @app.post("/api/update/download")
        def update_download() -> Any:
            return jsonify({"ok": True, "update_state": self.update_manager.start_update()})

        @app.post("/api/update/apply")
        def update_apply() -> Any:
            return jsonify({"ok": True, "update_state": self.update_manager.start_update()})

        @app.post("/api/update/restart")
        def update_restart() -> Any:
            return jsonify({"ok": True, "update_state": self.update_manager.restart()})

        @app.post("/api/discover")
        def discover() -> Any:
            locked = ensure_not_locked()
            if locked is not None:
                return locked
            if self.discovery is not None:
                self.discovery.send_probe()
            return jsonify({"ok": True})

        @app.post("/api/devices/<device_uid>/reject")
        def reject(device_uid: str) -> Any:
            locked = ensure_not_locked()
            if locked is not None:
                return locked
            config = self.config_store.deny(device_uid)
            return jsonify({"ok": True, "denied_devices": config.get("denied_devices", [])})

        @app.post("/api/devices/<device_uid>/allow")
        def allow(device_uid: str) -> Any:
            locked = ensure_not_locked()
            if locked is not None:
                return locked
            config = self.config_store.allow(device_uid)
            return jsonify({"ok": True, "denied_devices": config.get("denied_devices", [])})

        @app.post("/api/devices/<device_uid>/serve")
        def serve(device_uid: str) -> Any:
            locked = ensure_not_locked()
            if locked is not None:
                return locked
            if self.config_store.is_denied(device_uid):
                return jsonify({"ok": False, "error": "device_denied"}), 409
            if not self.upstream.is_connected():
                return jsonify({"ok": False, "error": "upstream_offline"}), 503
            claim = self.state.create_claim(device_uid)
            self.state.update_claim(claim["claim_id"], state="sent")
            self.upstream.send_claim_request(claim["device_uid"], claim["claim_id"], int(claim["ttl_ms"]))
            updated = self.state.update_claim(claim["claim_id"], state="requested")
            device_ip = self.state.last_findme_addr(device_uid)
            if device_ip and self.udp_control is not None:
                gw_id = str(self.config_store.snapshot().get("gateway_id") or "")
                self.udp_control.send_command_to(device_uid, (device_ip, _DEVICE_CONTROL_PORT), {
                    "command": "findme_switch_gateway",
                    "request_id": "findme-claim-{}".format(claim["claim_id"]),
                    "preferred_gateway_id": gw_id,
                    "claim_id": claim["claim_id"],
                    "ttl_ms": int(claim["ttl_ms"]),
                    "expires_at_ms": int(claim["expires_at_ms"]),
                })
            return jsonify({"ok": True, "claim": updated or claim})

        return app

    @staticmethod
    def _public_config(config: dict[str, Any]) -> dict[str, Any]:
        return dict(config)

    def _request_gateway_id_suggestion(self) -> str:
        return validate_gateway_id(f"nh-gateway-{secrets.token_hex(3)}")

    def _confirm_gateway_id_available(self, gateway_id: str) -> None:
        try:
            payload = self._server_api_post("/api/gateways/suggest-id", {"gateway_id": gateway_id})
        except urllib.error.HTTPError as exc:
            if exc.code == 409:
                raise ValueError("gateway_id_in_use") from exc
            if exc.code in (401, 403):
                raise ValueError("gateway_token_unauthorized") from exc
            return
        except urllib.error.URLError:
            return
        if payload.get("available") is False:
            raise ValueError("gateway_id_in_use")

    def _server_api_post(self, api_path: str, body: dict[str, Any]) -> dict[str, Any]:
        config = self.config_store.snapshot()
        base_url = self._http_base_from_gateway_ws(str(config.get("server_url") or ""))
        url = f"{base_url}{api_path}"
        data = json.dumps(body, separators=(",", ":")).encode("utf-8")
        request_obj = urllib.request.Request(url, data=data, method="POST", headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(request_obj, timeout=8) as response:
            payload = json.loads(response.read().decode("utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("invalid_server_response")
        return payload

    @staticmethod
    def _http_base_from_gateway_ws(server_url: str) -> str:
        parsed = urlparse(server_url)
        scheme = "https" if parsed.scheme == "wss" else "http"
        path = parsed.path or ""
        suffix = "/gateway/ws"
        if path.endswith(suffix):
            path = path[: -len(suffix)]
        return f"{scheme}://{parsed.netloc}{path}"

    def start(self) -> None:
        if self._server is not None:
            return
        self._server = make_server(self.host, self.port, self.app, threaded=True)
        self._thread = threading.Thread(target=self._server.serve_forever, name="newhorizons-gateway-web", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        server = self._server
        thread = self._thread
        self._server = None
        self._thread = None
        if server is not None:
            server.shutdown()
        if thread is not None:
            thread.join(timeout=1.0)
