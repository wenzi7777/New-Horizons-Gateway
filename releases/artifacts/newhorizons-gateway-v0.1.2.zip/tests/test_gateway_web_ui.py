import unittest
import tempfile
from pathlib import Path

from newhorizons_gateway.config_store import GatewayConfigStore
from newhorizons_gateway.state import GatewayState
from newhorizons_gateway.web import GatewayWebServer


ROOT = Path(__file__).resolve().parents[1]


class FakeUpstream:
    gateway_id = "local-gateway"

    def __init__(self):
        self.updated = []

    def status(self):
        return {"connected": False, "last_error": ""}

    def is_connected(self):
        return False

    def update_server(self, server_url, auth_token=None):
        self.updated.append((server_url, auth_token))

    def send_claim_request(self, *_args, **_kwargs):
        return None


class GatewayWebUiTest(unittest.TestCase):
    def test_gateway_config_defaults_token_to_uoacnlab(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GatewayConfigStore(str(Path(tmpdir) / "gateway_config.json"))

            self.assertEqual(store.snapshot()["auth_token"], "uoacnlab")

    def test_gateway_startup_defaults_token_to_uoacnlab(self):
        compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
        host_script = (ROOT / "scripts" / "start_gateway_host.sh").read_text(encoding="utf-8")

        self.assertIn("NEWHORIZONS_GATEWAY_TOKEN: ${NEWHORIZONS_GATEWAY_TOKEN:-uoacnlab}", compose)
        self.assertIn('export NEWHORIZONS_GATEWAY_TOKEN="${NEWHORIZONS_GATEWAY_TOKEN:-uoacnlab}"', host_script)

    def test_target_server_form_is_not_overwritten_while_dirty(self):
        web_source = (ROOT / "newhorizons_gateway" / "web.py").read_text(encoding="utf-8")

        self.assertIn("let targetSettingsDirty = false", web_source)
        self.assertIn("if (targetSettingsDirty) return;", web_source)
        self.assertIn('"target-mode").addEventListener("change"', web_source)
        self.assertIn("targetSettingsDirty = false;", web_source)

    def test_compose_does_not_force_production_mode_over_saved_config(self):
        compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")

        self.assertIn("NEWHORIZONS_GATEWAY_TARGET_MODE: ${NEWHORIZONS_GATEWAY_TARGET_MODE:-}", compose)

    def test_start_gateway_defaults_to_host_gateway_on_macos(self):
        script = (ROOT / "scripts" / "start_gateway.sh").read_text(encoding="utf-8")

        self.assertIn('HOST_GATEWAY=1', script)
        self.assertIn('exec "${SCRIPT_DIR}/start_gateway_host.sh"', script)
        self.assertIn("--docker", script)

    def test_host_gateway_script_uses_screen_for_persistent_background_run(self):
        script = (ROOT / "scripts" / "start_gateway_host.sh").read_text(encoding="utf-8")

        self.assertIn("SESSION_NAME=", script)
        self.assertIn("screen -dmS", script)
        self.assertIn("screen:${SESSION_NAME}", script)

    def test_gateway_runtime_is_udp_only_by_default(self):
        main_source = (ROOT / "newhorizons_gateway" / "main.py").read_text(encoding="utf-8")
        local_device_source = (ROOT / "newhorizons_gateway" / "local_device.py").read_text(encoding="utf-8")
        web_source = (ROOT / "newhorizons_gateway" / "web.py").read_text(encoding="utf-8")

        self.assertNotIn("LocalTCPControlServer", main_source)
        self.assertNotIn("LocalTCPControlServer", local_device_source)
        self.assertNotIn("socketserver", local_device_source)
        self.assertNotIn("json.dumps", local_device_source)
        self.assertNotIn("tcp_server.send_command", main_source)
        self.assertNotIn("TCP control", web_source)
        self.assertNotIn("TCP</th>", web_source)

    def test_gateway_web_ui_removes_os_eyebrow_and_adds_id_enable_update_controls(self):
        web_source = (ROOT / "newhorizons_gateway" / "web.py").read_text(encoding="utf-8")

        self.assertNotIn('<div class="eyebrow">New Horizons OS</div>', web_source)
        self.assertIn('id="gateway-id-input"', web_source)
        self.assertIn('id="setup-wizard"', web_source)
        self.assertIn('id="setup-gateway-id-input"', web_source)
        self.assertIn('id="gateway-enabled"', web_source)
        self.assertIn('id="auto-gateway-id"', web_source)
        self.assertIn('id="check-update"', web_source)
        self.assertIn('id="download-update"', web_source)
        self.assertIn('id="apply-update"', web_source)

    def test_gateway_setup_wizard_prefetches_id_once_without_overwriting_input(self):
        web_source = (ROOT / "newhorizons_gateway" / "web.py").read_text(encoding="utf-8")

        self.assertIn("let setupGatewayIdSuggested = false", web_source)
        self.assertIn("if (!hasGatewayId && !setupGatewayIdSuggested)", web_source)
        self.assertIn('document.getElementById("setup-gateway-id-input").value = payload.gateway_id || ""', web_source)
        self.assertIn("setupGatewayIdSuggested = true", web_source)

    def test_gateway_config_defaults_disabled_and_persists_enable_state(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "gateway_config.json"
            store = GatewayConfigStore(str(path))

            self.assertFalse(store.snapshot()["enabled"])
            self.assertEqual(store.snapshot()["gateway_id"], "")

            saved = store.save({"gateway_id": "nh-gateway-test", "enabled": True})
            self.assertTrue(saved["enabled"])
            self.assertEqual(saved["gateway_id"], "nh-gateway-test")

            reloaded = GatewayConfigStore(str(path))
            self.assertTrue(reloaded.snapshot()["enabled"])
            self.assertEqual(reloaded.snapshot()["gateway_id"], "nh-gateway-test")

    def test_gateway_settings_require_valid_id_before_enable(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GatewayConfigStore(str(Path(tmpdir) / "gateway_config.json"))
            server = GatewayWebServer("127.0.0.1", 0, store, GatewayState(), FakeUpstream(), None)
            client = server.app.test_client()

            missing = client.post("/api/settings", json={"enabled": True, "gateway_id": ""})
            bad = client.post("/api/settings", json={"enabled": True, "gateway_id": "bad id!"})
            good = client.post("/api/settings", json={"enabled": True, "gateway_id": "nh-gateway-test"})

            self.assertEqual(missing.status_code, 400)
            self.assertEqual(bad.status_code, 400)
            self.assertEqual(good.status_code, 200)
            self.assertTrue(good.get_json()["config"]["enabled"])

    def test_gateway_settings_callback_receives_saved_config(self):
        seen = []
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GatewayConfigStore(str(Path(tmpdir) / "gateway_config.json"))
            server = GatewayWebServer("127.0.0.1", 0, store, GatewayState(), FakeUpstream(), None, on_config_saved=seen.append)
            client = server.app.test_client()

            response = client.post("/api/settings", json={"enabled": True, "gateway_id": "nh-gateway-test"})

            self.assertEqual(response.status_code, 200)
            self.assertEqual(seen[-1]["gateway_id"], "nh-gateway-test")
            self.assertTrue(seen[-1]["enabled"])

    def test_gateway_status_reports_token_plaintext_for_local_web_ui(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GatewayConfigStore(str(Path(tmpdir) / "gateway_config.json"))
            store.save({"gateway_id": "nh-gateway-test", "auth_token": "secret-token"})
            server = GatewayWebServer("127.0.0.1", 0, store, GatewayState(), FakeUpstream(), None)
            client = server.app.test_client()

            response = client.get("/api/status")

            self.assertEqual(response.status_code, 200)
            payload = response.get_json()
            self.assertEqual(payload["config"]["auth_token"], "secret-token")
            self.assertTrue(payload["config"]["auth_token_configured"])

    def test_gateway_settings_can_update_preserve_and_clear_token(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GatewayConfigStore(str(Path(tmpdir) / "gateway_config.json"))
            upstream = FakeUpstream()
            server = GatewayWebServer("127.0.0.1", 0, store, GatewayState(), upstream, None)
            client = server.app.test_client()

            update = client.post(
                "/api/settings",
                json={"gateway_id": "nh-gateway-test", "auth_token": "secret-token"},
            )
            preserve = client.post("/api/settings", json={"gateway_id": "nh-gateway-test", "manual_url": "ws://example/ws"})
            clear = client.post("/api/settings", json={"gateway_id": "nh-gateway-test", "clear_auth_token": True})

            self.assertEqual(update.status_code, 200)
            self.assertEqual(preserve.status_code, 200)
            self.assertEqual(clear.status_code, 200)
            self.assertEqual(update.get_json()["config"]["auth_token"], "secret-token")
            self.assertTrue(update.get_json()["config"]["auth_token_configured"])
            self.assertEqual(upstream.updated[0][1], "secret-token")
            self.assertEqual(preserve.get_json()["config"]["auth_token_configured"], True)
            self.assertEqual(clear.get_json()["config"]["auth_token_configured"], False)
            self.assertEqual(store.snapshot()["auth_token"], "")

    def test_gateway_settings_can_clear_token_while_enabled_without_server_check(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            store = GatewayConfigStore(str(Path(tmpdir) / "gateway_config.json"))
            store.save({"gateway_id": "nh-gateway-test", "enabled": True, "auth_token": "secret-token"})
            server = GatewayWebServer("127.0.0.1", 0, store, GatewayState(), FakeUpstream(), None)
            server._confirm_gateway_id_available = lambda _gateway_id: (_ for _ in ()).throw(AssertionError("unexpected server check"))
            client = server.app.test_client()

            response = client.post(
                "/api/settings",
                json={"gateway_id": "nh-gateway-test", "enabled": True, "clear_auth_token": True},
            )

            self.assertEqual(response.status_code, 200)
            self.assertFalse(response.get_json()["config"]["auth_token_configured"])

    def test_gateway_web_ui_has_token_controls(self):
        web_source = (ROOT / "newhorizons_gateway" / "web.py").read_text(encoding="utf-8")

        self.assertIn('id="gateway-token-input"', web_source)
        self.assertIn('type="text"', web_source)
        self.assertIn('config.auth_token || ""', web_source)
        self.assertIn('id="clear-gateway-token"', web_source)
        self.assertIn("auth_token_configured", web_source)
        self.assertIn("clear_auth_token", web_source)


if __name__ == "__main__":
    unittest.main()
